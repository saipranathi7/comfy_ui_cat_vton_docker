# Do something before running CMD
echo "Do something before running CMD"

# Run whatever entrypoint / cmd args are passed next
"$@"