import * as jsesc from 'jsesc';

export function message() {
    return jsesc('Hello World!')
}
